/**
 * Copyright (c) 2017 Motorola Mobility, LLC.
 * Walk Assist 1.0
 */

package com.motorola.samples.mdkrawstub;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.motorola.mod.ModDevice;
import com.motorola.mod.ModManager;

import java.nio.ByteBuffer;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private ModManagerInterface modManager; // for attach/detach and interface
    private ModRawStub modRaw;              // Raw handler
    private Context mContext;
    private final int RC_VIBRATE = 1;
    private boolean modAttached = false;
    private float previousValue = 0;

    Button onOffButton;

    public static byte [] Raw_cmd1 = {0x01};
    public static byte [] Raw_cmd2 = {0x00};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContext = this;

        // Find and initialize views
        onOffButton = (Button) findViewById(R.id.on_off_button);
        onOffButton.setText("Turn on");

        init();
    }

    public void init(){
        final Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        onOffButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick (View v) {
                onOffButton = (Button) findViewById(R.id.on_off_button);
                String onOff = onOffButton.getText().toString();
                if(onOff == "Turn on") {
                    if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.VIBRATE) == PackageManager.PERMISSION_GRANTED) {
                        onOffButton.setText("Turn off");
                        vib.vibrate(new long[]{0, 50, 150, 50, 150, 50}, -1);
                        refreshProximity.run();
                    } else {
                        ActivityCompat.requestPermissions((MainActivity) mContext, new String[]{Manifest.permission.VIBRATE}, RC_VIBRATE);
                    }
                } else {
                    if(modAttached)
                        modRaw.writeRequest(Raw_cmd2);
                    rawHandler.removeCallbacks(refreshProximity);
                    vibrateProximity(50001);
                    vib.vibrate(new long[]{0, 50, 150, 50, 150, 50}, -1);
                    onOffButton.setText("Turn on");
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        rawHandler.removeCallbacks(refreshProximity);
        releaseModManager();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        initModManager();           // Connect ModManagerInterface service
    }

    private void initModManager() {
        if (null == modManager) {
            modManager = new ModManagerInterface(this);
            modManager.registerListener(modHandler);
        }
    }

    private void releaseModManager() {
        if (null != modRaw) {
            modRaw.onModDevice(null);
            modRaw = null;
        }
        if (null != modManager) {
            modManager.onDestroy();
            modManager = null;
        }
    }


    // Handle messages from the ModManagerInterface
    private Handler modHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case ModManagerInterface.MSG_MOD_DEVICE:
                    ModDevice device = modManager.getModDevice();
                    onModDevice(device);
                    break;
            }
        }
    };

    // Called on Moto Mod attach/detach
    public void onModDevice(ModDevice device) {
        if (null == device) {
            modAttached = false;
            /*
            if (null != vidpid) {
                vidpid.setText(getString(R.string.no_mod));
            }
            */
            if (null != modRaw) {
                modRaw.onModDevice(null);   // Close Raw interfaces
                modRaw = null;
            }
            //writeButton.setEnabled(false);
        } else {
            modAttached = true;
            int vendorId = device.getVendorId();
            /*
            if (null != vidpid) {
                String info = String.format("0x%08x/0x%08x",
                        vendorId, device.getProductId());
                vidpid.setText(info);
            }
            */
            // Before opening Raw, ALWAYS confirm
            // that you're talking to YOUR Moto Mod
            if (vendorId == Constants.VID_DEVELOPER) {
                // Connect the Raw interface
                if (null == modRaw) {
                    modRaw = new ModRawStub(this, modManager);
                    modRaw.registerListener(rawHandler);
                    modRaw.onModDevice(device);
                }
            }
        }
    }

    private static int RAW_REQUEST_CODE = 0x25;
    private Handler rawHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case ModRawStub.MSG_RAW_REQUEST_PERMISSION:
                    requestPermissions(new String[]{ModManager.PERMISSION_USE_RAW_PROTOCOL},
                            RAW_REQUEST_CODE);
                    break;
                case ModRawStub.MSG_RAW_IO_READY:
                    //writeButton.setEnabled(true);
                    break;
                case ModRawStub.MSG_RAW_DATA:
                    String text = new String((byte[]) msg.obj);
                    byte[] buff = (byte[]) msg.obj;
                    int length = msg.arg1;
                    byte[] content = new byte[4];
                    for (int i = 1; i < 5; i++) {
                        content[4 - i] = buff[i];
                    }
                    float value = ByteBuffer.wrap(content).getFloat();
                    vibrateProximity(value);
                    //soundProximity(value);
                    break;
            }
        }
    };

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == RAW_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                modRaw.onPermissionGranted(true);
            } else {
                Toast toast = Toast.makeText(mContext, "Device permission is needed!", Toast.LENGTH_LONG);
                toast.show();
            }
        } else if (requestCode == RC_VIBRATE){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //do nothing
            } else {
                Toast toast = Toast.makeText(mContext, "Vibrate permission is needed!", Toast.LENGTH_LONG);
                toast.show();
            }
        }
    }

    public void vibrateProximity(float proximity){
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if(previousValue < 2500) {
            if (Math.abs(proximity - previousValue) > 100) {
                if (proximity < 4000) {
                    vibrator.vibrate(new long[]{0, 150, (long) proximity * 7/10, 150}, 2);

                } else {
                    vibrator.cancel();
                }
            }
        } else {
            if (Math.abs(proximity - previousValue) > 500) {
                if (proximity < 4000) {
                    vibrator.vibrate(new long[]{0, 150, (long) proximity * 7/10, 150}, 2);

                } else {
                    vibrator.cancel();
                }
            }
            previousValue = proximity;
        }
        previousValue = proximity;
    }

    /* Playing sound instead of vibrating, feature not included on final project
    public void soundProximity(float proximity) {
        if (Math.abs(proximity - previousValue) > 500) {
            if (proximity < 100) {
                MediaPlayer mp = MediaPlayer.create(getApplicationContext(), R.raw.long_long_beep);
                if (mp.isPlaying())
                    mp.stop();
                mp.start();
                previousValue = proximity;

            } else if (proximity < 3000) {
                final MediaPlayer mp = MediaPlayer.create(getApplicationContext(), R.raw.beep);
                if (mp.isPlaying())
                    mp.stop();

                final Timer t = new Timer();
                final int[] count = {0};
                t.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        count[0]++;
                        mp.start();
                        if (count[0] >= 10)
                            t.cancel();
                    }
                }, 0, (int) proximity);

                previousValue = proximity;

            }
        }
    }*/

    /** Runnable */
    private Runnable refreshProximity = new Runnable() {
        @Override
        public void run() {
            int mInterval = 500; // 1.0 second interval to refresh Display
            if(modAttached)
                modRaw.writeRequest(Raw_cmd1);
            rawHandler.postDelayed(refreshProximity, mInterval);
        }
    };
}