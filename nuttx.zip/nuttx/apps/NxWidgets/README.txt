apps/NxWidgets README File
==========================

The NxWidgets and NxWM libraries don't physically reside in the apps/ source
tree.  The source code actually resides at the top level NxWidgets/
directory.  This directory is just a kludge...it is here only support
configuration of NxWidgets and NxWM.

The only files that reside in this directory are (1) this README.txt file
and (2) the Kconfig file to support NxWidgets configuration.  This is a
duplicate of the NxWidgets file that you can file at NxWidgets/Kconfig.
