/****************************************************************************
 * apps/nshlib/nsh_stdsession.c
 *
 *   Copyright (C) 2013-2014 Gregory Nutt. All rights reserved.
 *   Author: Gregory Nutt <gnutt@nuttx.org>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name Gregory Nutt nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>

#include <stdio.h>
#include <stdlib.h>

#ifdef CONFIG_NSH_CLE
#  include <apps/cle.h>
#else
#  include <apps/readline.h>
#endif

#include "nsh.h"
#include "nsh_console.h"

/****************************************************************************
 * Pre-processor Definitions
 ****************************************************************************/

/****************************************************************************
 * Private Types
 ****************************************************************************/

/****************************************************************************
 * Private Function Prototypes
 ****************************************************************************/

/****************************************************************************
 * Private Data
 ****************************************************************************/

/****************************************************************************
 * Public Data
 ****************************************************************************/

/****************************************************************************
 * Private Functions
 ****************************************************************************/

/****************************************************************************
 * Public Functions
 ****************************************************************************/

/****************************************************************************
 * Name: nsh_session
 *
 * Description:
 *   This is the common session logic or an NSH session that uses only stdin
 *   and stdout.
 *
 *   This function:
 *   - Executes the NSH logic script
 *   - Presents a greeting
 *   - Then provides a prompt then gets and processes the command line.
 *   - This continues until an error occurs, then the session returns.
 *
 * Input Parameters:
 *   pstate - Abstracts the underlying session.
 *
 * Returned Values:
 *   EXIT_SUCESS only
 *
 ****************************************************************************/

int nsh_session(FAR struct console_stdio_s *pstate)
{
  int ret;

  DEBUGASSERT(pstate);

  /* Present a greeting */

  printf("%s", g_nshgreeting);

  /* Then enter the command line parsing loop */

  for (;;)
    {
      /* For the case of debugging the USB console... dump collected USB trace data */

#ifdef CONFIG_NSH_USBDEV_TRACE
      nsh_usbtrace();
#endif

      /* Display the prompt string */

      printf("%s", g_nshprompt);

      /* Get the next line of input. readline() returns EOF on end-of-file
       * or any read failure.
       */

#ifdef CONFIG_NSH_CLE
      ret = cle(pstate->cn_line, CONFIG_NSH_LINELEN,
                stdin, stdout);
#else
      ret = std_readline(pstate->cn_line, CONFIG_NSH_LINELEN);
#endif
      if (ret != EOF)
        {
          /* Parse process the command */

          (void)nsh_parse(&pstate->cn_vtbl, pstate->cn_line);
        }

      /* Readline normally returns the number of characters read,
       * but will return EOF on end of file or if an error occurs.
       * EOF will cause the session to terminate.
       */

      else
        {
          printf(g_fmtcmdfailed, "nsh_session", "readline", NSH_ERRNO_OF(-ret));
          return EXIT_SUCCESS;
        }
    }

  /* We do not get here, but this is necessary to keep some compilers happy.
   * But others will complain that this code is not reachable.
   */

  return EXIT_SUCCESS;
}
