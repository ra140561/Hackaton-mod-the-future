int bq25896_main(int argc, char *argv[]);
int dev_info_main(int argc, char *argv[]);
int gpio_main(int argc, char *argv[]);
int sysinfo_main(int argc, char *argv[]);
