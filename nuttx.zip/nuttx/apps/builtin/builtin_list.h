{ "bq25896", SCHED_PRIORITY_DEFAULT, 2048, bq25896_main },
{ "dev_info", SCHED_PRIORITY_DEFAULT, 2048, dev_info_main },
{ "gpio", SCHED_PRIORITY_DEFAULT, 2048, gpio_main },
{ "sysinfo", SCHED_PRIORITY_DEFAULT, 1024, sysinfo_main },
