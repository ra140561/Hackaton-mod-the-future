lib/ README File
================

This directory is reserved for libraries generated during the NuttX build process


