# Hackathon-mod-the-future
Motorola Snaps hacking

Developing a tool based on a ultrasonic range sensor
 
